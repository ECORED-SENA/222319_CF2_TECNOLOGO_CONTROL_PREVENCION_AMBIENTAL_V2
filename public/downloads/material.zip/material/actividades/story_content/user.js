function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6FaWIq8vOtR":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

